<?php
/**
 * @file
 * A cached plugin object that tests including.
 */

class ctoolsNotCachedPluginArray2 {}
