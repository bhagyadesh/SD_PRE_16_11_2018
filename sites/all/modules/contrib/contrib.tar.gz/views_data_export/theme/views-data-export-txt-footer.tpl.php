<?php

/**
 * TXT files don't really have a footer.
 */