/**
 * @file
 *
 * Javascript to add placeholder events.
 */

(function ($) {
  Drupal.behaviors.placeholder = {
    attach: function () {
      if(typeof($("input[placeholder], textarea[placeholder]").placeholder())=='function') {
        $("input[placeholder], textarea[placeholder], password[placeholder]").placeholder();
      }
    }
  };

})(jQuery);
