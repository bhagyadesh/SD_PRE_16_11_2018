<?php
  print render($only_diff_checkbox);
  print render($comparison_table);
?>


